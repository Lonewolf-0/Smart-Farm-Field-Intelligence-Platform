// Minimal Polygon type to avoid pulling geojson types in the frontend build
export type Polygon = any;
// ==========================
// API RESPONSE WRAPPER
// ==========================
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
}

// ==========================
//  CORE ENTITIES
// ==========================
export interface User {
  id: string;
  email: string;
  name: string;
  createdAt: string;
}

export interface Field {
  id: string;
  name: string;
  polygon: Polygon;
  area: number;
  centroid: {
    lat: number;
    lng: number;
  };
  userId: string;
}

export interface SoilData {
  id: string;
  fieldId: string;
  ph: number;
  organicCarbon: number;
  nitrogen: number;
  phosphorus: number;
  potassium: number;
  clay: number;
  sand: number;
  texture: string;
  year: number;
  season: string;
}

// ==========================
//  WEATHER
// ==========================
export interface ForecastDay {
  date: string;
  tempMax: number;
  tempMin: number;
  precipitation: number;
  condition: string;
}

export interface WeatherData {
  temperature: number;
  humidity: number;
  windSpeed: number;
  rainfall: number;
  forecast: ForecastDay[];
}

// ==========================
//  ANALYTICS
// ==========================
export interface CropSuitability {
  name: string;
  score: number;
  breakdown: {
    ph: number;
    temperature: number;
    rainfall: number;
    soilTexture: number;
  };
}

export interface IrrigationPlan {
  nextIrrigationDays: number;
  waterRequired: number;
  soilMoisture: number;
  evapotranspiration: number;
}

export interface NDVIData {
  averageNDVI: number;
  healthScore: number;
  stressZones: number[];
  timestamp: string;
}

export interface FertilizerProduct {
  name: string;
  quantity: number;
  unit: string;
}

export interface FertilizerStep {
  stage: string;
  days: number;
  description: string;
  recommendations: FertilizerProduct[];
}

export interface LiveAdjustment {
  type: "warning" | "info" | "success";
  message: string;
}

export interface FertilizerPlan {
  crop: string;
  nitrogenDeficit: number;
  phosphorusDeficit: number;
  potassiumDeficit: number;
  recommendations: FertilizerProduct[];
  totalQuantity: number;
  applicationSchedule: string[];
  scheduleSteps?: FertilizerStep[];
  liveDataAdjustments?: LiveAdjustment[];
  soilBaselines?: {
    nitrogen: number;
    phosphorus: number;
    potassium: number;
  };
}

export interface PesticideRecommendation {
  product: string;
  dosage: string;
  timing: string;
  safety: string;
  pestRisk: string;
}

export interface ProfitAnalysis {
  revenue: number;
  costs: number;
  profit: number;
  perAcre: number;
  crop: string;
  yield: number;
}

export interface RiskAlert {
  type: string;
  severity: "low" | "medium" | "high" | "critical" | string;
  message: string;
  expectedDate: string;
  duration?: string;
  recommendation?: string;
}

// ==========================
// BRANCH / MARKET
// ==========================
export interface BranchProduct {
  name: string;
  price: number;
  unit: string;
}

export interface NutrienBranch {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
  address: string;
  phone: string;
  services: string[];
  products: BranchProduct[];
}

// ==========================
//  FINAL AGGREGATED OUTPUT
// ==========================
export interface FieldAnalysis {
  soilData: SoilData;
  weather: WeatherData;
  cropSuitability: CropSuitability[];
  irrigation: IrrigationPlan;
  ndvi: NDVIData;
  fertilizer: FertilizerPlan;
  pesticide: PesticideRecommendation[];
  profit: ProfitAnalysis;
  risks: RiskAlert[];
}

// ==========================
// REQUEST TYPES
// ==========================

// AUTH
export interface RegisterRequest {
  email: string;
  password: string;
  name: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

// FIELD
export interface CreateFieldRequest {
  name: string;
  polygon: Polygon;
}

export interface UpdateFieldRequest {
  name?: string;
  polygon?: Polygon;
}

// SOIL
export interface AddSoilDataRequest {
  fieldId: string;
  ph: number;
  organicCarbon: number;
  nitrogen: number;
  phosphorus: number;
  potassium: number;
  clay: number;
  sand: number;
  texture: string;
  year: number;
  season: string;
}

// ANALYSIS
export interface AnalysisRequest {
  fieldId: string;
}
